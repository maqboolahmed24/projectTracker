import { markSVG } from './mark.js';

export { markSVG };

const activeMarks = new WeakMap();

/** Animate the supplied logo paths without changing their settled geometry. */
export function animateMark(svg, { reducedMotion } = {}) {
  activeMarks.get(svg)?.cancel();
  const media = window.matchMedia('(prefers-reduced-motion: reduce)');
  const reduce = reducedMotion ?? media.matches;
  const bars = [...svg.querySelectorAll('.ukds-bar')];
  const span = svg.viewBox.baseVal.width;
  const animations = [];
  const masks = [];
  const ns = 'http://www.w3.org/2000/svg';
  const definitions = document.createElementNS(ns, 'defs');
  const runId = `ukds-motion-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  const thickness = Math.min(...bars.filter((bar) => bar.dataset.arm === 'left')
    .map((bar) => bar.getBBox().width));
  const directions = { top: [-0.325, -0.50], left: [-0.50, 0.275], right: [0.50, 0.275] };
  const offsets = { top: 80, left: 340, right: 600 };
  if (!reduce) svg.prepend(definitions);

  for (const [index, bar] of bars.entries()) {
    const arm = bar.dataset.arm || 'top';
    const order = Number(bar.dataset.order || 0);
    const [x, y] = directions[arm] || directions.top;
    const delay = (offsets[arm] || 0) + order * 60;

    if (!reduce) {
      // Reveal each filled bar along its own axis. The settled artwork stays
      // untouched; these slightly wider masks disappear after the arrival.
      const box = bar.getBBox();
      const radius = thickness / 2;
      const start = arm === 'left'
        ? [box.x + box.width / 2, box.y + box.height - radius]
        : arm === 'top'
          ? [box.x + radius, box.y + radius]
          : [box.x + box.width - radius, box.y + radius];
      const end = arm === 'left'
        ? [box.x + box.width / 2, box.y + radius]
        : arm === 'top'
          ? [box.x + box.width - radius, box.y + box.height - radius]
          : [box.x + radius, box.y + box.height - radius];
      const length = Math.hypot(end[0] - start[0], end[1] - start[1]);
      const revealWidth = thickness * 1.65;
      const mask = document.createElementNS(ns, 'mask');
      mask.id = `${runId}-${index}`;
      mask.setAttribute('maskUnits', 'userSpaceOnUse');
      mask.setAttribute('x', String(box.x - revealWidth));
      mask.setAttribute('y', String(box.y - revealWidth));
      mask.setAttribute('width', String(box.width + revealWidth * 2));
      mask.setAttribute('height', String(box.height + revealWidth * 2));
      const line = document.createElementNS(ns, 'path');
      line.setAttribute('d', `M ${start.join(' ')} L ${end.join(' ')}`);
      line.setAttribute('fill', 'none');
      line.setAttribute('stroke', '#fff');
      line.setAttribute('stroke-width', String(revealWidth));
      line.setAttribute('stroke-linecap', 'round');
      line.setAttribute('stroke-dasharray', `${length} ${length + revealWidth * 2}`);
      mask.append(line);
      definitions.append(mask);
      const reference = `url(#${mask.id})`;
      masks.push({ bar, reference, previous: bar.getAttribute('mask') });
      bar.setAttribute('mask', reference);
      animations.push(line.animate(
        [{ strokeDashoffset: `${length + revealWidth}px` }, { strokeDashoffset: '0px' }],
        { duration: 1180, delay, easing: 'cubic-bezier(0.22, 0.61, 0.36, 1)', fill: 'both' },
      ));
    }

    animations.push(bar.animate(
      reduce
        ? [{ opacity: 0 }, { opacity: 1 }]
        : [
            { offset: 0, opacity: 0, transform: `translate(${x * span}px, ${y * span}px)` },
            { offset: 0.12, opacity: 1 },
            { offset: 1, opacity: 1, transform: 'translate(0px, 0px)' },
          ],
      {
        duration: reduce ? 160 : 1520,
        delay: reduce ? 0 : delay,
        easing: 'cubic-bezier(0.22, 0.8, 0.24, 1)',
        fill: 'both',
      },
    ));
  }

  // A preference changed during launch takes effect immediately.
  const onMotionChange = () => {
    if (media.matches) for (const animation of animations) animation.finish();
  };
  media.addEventListener('change', onMotionChange);
  function clear() {
    for (const animation of animations) animation.cancel();
    for (const { bar, reference, previous } of masks) {
      // A quick replay may already own the next mask by the time promises settle.
      if (bar.getAttribute('mask') !== reference) continue;
      if (previous === null) bar.removeAttribute('mask');
      else bar.setAttribute('mask', previous);
    }
    definitions.remove();
    media.removeEventListener('change', onMotionChange);
    if (activeMarks.get(svg) === handle) activeMarks.delete(svg);
  }
  const finished = Promise.all(animations.map((animation) => animation.finished.catch(() => {})))
    .then(clear);

  const handle = { finished, cancel: clear };
  activeMarks.set(svg, handle);
  return handle;
}

/**
 * Optional launch decoration. App readiness and error UI remain with the caller.
 * @param {{ready?: PromiseLike<unknown>, appRoot?: HTMLElement,
 * theme?: 'light'|'dark'|'auto', minDuration?: number, maxDuration?: number,
 * stylesheetUrl?: string|URL}} options
 */
export function mountUKDALaunch(options = {}) {
  if (typeof document === 'undefined') throw new Error('Mount the launch screen in a browser.');
  if (!document.body) throw new Error('Mount the launch screen after <body> exists.');

  const {
    ready, appRoot, theme = 'light', minDuration = 2850,
    maxDuration = 10000, stylesheetUrl = new URL('./ukda-launch.css', import.meta.url),
  } = options;
  if (!['light', 'dark', 'auto'].includes(theme)) throw new TypeError('Unknown launch theme.');
  if (!Number.isFinite(minDuration) || !Number.isFinite(maxDuration) ||
      minDuration < 0 || maxDuration <= minDuration) {
    throw new RangeError('Durations must be finite, with 0 <= minDuration < maxDuration.');
  }
  if (appRoot && (!(appRoot instanceof HTMLElement) || appRoot === document.body ||
      !document.body.contains(appRoot))) {
    throw new TypeError('appRoot must be an element inside this document body.');
  }

  const host = document.createElement('div');
  host.hidden = true;
  host.dataset.ukdaLaunch = '';
  host.dataset.theme = theme;
  const shadow = host.attachShadow({ mode: 'open' });
  const stylesheet = document.createElement('link');
  stylesheet.rel = 'stylesheet';
  stylesheet.href = String(stylesheetUrl);
  const stage = document.createElement('div');
  stage.className = 'ukda-launch-stage';
  stage.innerHTML = markSVG;
  const svg = stage.querySelector('svg');
  svg.setAttribute('aria-hidden', 'true');
  svg.removeAttribute('role');
  const status = document.createElement('span');
  status.className = 'ukda-launch-status';
  status.setAttribute('role', 'status');
  status.textContent = 'Opening application';
  shadow.append(stylesheet, stage, status);

  const media = window.matchMedia('(prefers-reduced-motion: reduce)');
  const timers = new Map();
  const initiallyInert = appRoot?.inert;
  let ownsInert = false;
  let settled = false;
  let exiting = false;
  let entrance;
  let exitAnimation;
  let markExitAnimation;
  let releaseReady;
  let resolveFinished;
  const readySignal = new Promise((resolve) => { releaseReady = resolve; });
  const finished = new Promise((resolve) => { resolveFinished = resolve; });

  function pause(ms) {
    return new Promise((resolve) => {
      const id = setTimeout(() => { timers.delete(id); resolve(); }, ms);
      timers.set(id, resolve);
    });
  }

  function cleanup(reason, error) {
    if (settled) return;
    settled = true;
    host.remove();
    entrance?.cancel();
    exitAnimation?.cancel();
    markExitAnimation?.cancel();
    clearTimeout(watchdog);
    for (const [id, resolve] of timers) { clearTimeout(id); resolve(); }
    timers.clear();
    releaseReady();
    releaseStyles();
    stylesheet.onload = stylesheet.onerror = null;
    media.removeEventListener('change', onMotionChange);
    if (ownsInert) appRoot.inert = initiallyInert;
    resolveFinished(error ? { reason, error } : { reason });
  }

  async function exit(reason, error) {
    if (settled || exiting) return;
    exiting = true;
    try {
      if (!host.hidden) {
        const duration = media.matches ? 120 : 480;
        if (!media.matches) {
          markExitAnimation = stage.animate([{ opacity: 1 }, { opacity: 0 }], {
            duration: 280, easing: 'cubic-bezier(0.4, 0, 1, 1)', fill: 'forwards',
          });
        }
        exitAnimation = host.animate([
          { opacity: 1, offset: 0 },
          { opacity: 1, offset: media.matches ? 0 : 0.18 },
          { opacity: 0, offset: 1 },
        ], {
          duration, easing: 'cubic-bezier(0.4, 0, 0.2, 1)', fill: 'forwards',
        });
        // The timer also covers background tabs that pause animation timelines.
        await Promise.race([exitAnimation.finished.catch(() => {}), pause(duration + 100)]);
      }
    } catch (animationError) {
      reason = 'error';
      error ??= animationError;
    } finally {
      cleanup(reason, error);
    }
  }

  function onMotionChange() {
    if (media.matches) { exitAnimation?.finish(); markExitAnimation?.finish(); }
  }
  media.addEventListener('change', onMotionChange);

  let releaseStyles;
  const stylesReady = new Promise((resolve, reject) => {
    releaseStyles = resolve;
    stylesheet.onload = resolve;
    stylesheet.onerror = () => reject(new Error('Launch stylesheet could not load.'));
  });
  // Hard cap includes resource loading and the exit, never blocks the app forever.
  const watchdog = setTimeout(() => cleanup('timeout'), maxDuration);
  document.body.append(host);

  // Observe immediately so an early initialization failure cannot go unhandled.
  Promise.resolve(ready).then(() => releaseReady(), (error) => exit('error', error));

  (async () => {
    try {
      await stylesReady;
      if (settled || exiting) return;
      if (appRoot) { appRoot.inert = true; ownsInert = true; }
      host.hidden = false;
      entrance = animateMark(svg);
      // Reduced motion does not impose the branded waiting period.
      const minimum = media.matches ? 180 : minDuration;
      await Promise.all([entrance.finished, pause(minimum), readySignal]);
      if (!settled) await exit('ready');
    } catch (error) {
      await exit('error', error);
    }
  })();

  return {
    finished,
    finish() { releaseReady(); },
    destroy() { cleanup('destroyed'); },
  };
}
